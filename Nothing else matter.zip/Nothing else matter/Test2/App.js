import React, {useState} from "react"
import {BrowserRouter as Router} from "react-router-dom"
import Web3 from "web3"

import {Context} from "./Context"
import Routers from "./Router"
import {ABI} from "./Abi"

const App=()=>{
  const [web3] = useState(new Web3("http://127.0.0.1:8545"))
  const Address = "0x1a5349904d63529e7411AE2b443F8a25428C023C"
  const [Contract] = useState(new web3.eth.Contract(ABI, Address))

  return (
    <Router>
      <Context.Provider value={{web3, Contract}}>
        <Routers/>
      </Context.Provider>
    </Router>
  )
}

export default App;
