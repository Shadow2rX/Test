import React, {useState, useEffect} from "react"
import {UseContext} from "./Context"

const Main=()=>{

    const {web3, Contract} = UseContext()
    const [Accounts, setAccounts] = useState([])
    const [address, setAddress] = useState('')
    const [Login, setLogin] = useState('')
    const [password, setPassword] = useState('')
    const [addressTo, setAddressTo] = useState('')
    const [category, setCategory] = useState('')
    const [description, setDescription] = useState('')
    const [codeword, setCodeword] = useState('')
    const [value, setValue] = useState('')
    const [TransferID, setTransferID] = useState('')
    const [name, setName] = useState('')
    const [offerID, setOfferID] = useState('')
    const [voteUser, setVote] = useState('')
    const [nameTemplate, setNameTemplate] = useState("");
    const [valueTemplate, setValueTemplate] = useState("");
    const [checked, setChecked] = useState(true)
//--------------------------------------------------------USEEFFECT----------------------
    useEffect(() => {

        ListAccounts()

        Vote_user_false()
    },[])

    const ListAccounts=async()=>{
        let Users= await web3.eth.getAccounts()
        Users[0]="Choose address" 
        setAccounts(Users)
    }
    
    const Vote_user_false=async()=>{
        try{
            setVote(false)
        }catch(e){
            alert(e)
        }
    }

    const chengeCheckbox = async()=> {
        setChecked(!checked);
     }
//------------------------------------------------------USERS_AND_ADMINS--------------------------------------
    const UserInfo=async(e)=>{
        e.preventDefault()
        try{
            let addr = sessionStorage.getItem("address")
            let balance = await web3.eth.getBalance(sessionStorage.getItem("address"))
            let role = await Contract.methods.get_role(sessionStorage.getItem("address")).call()
            alert(`
            User: ${addr}; 
            Balance = ${balance}; 
            Role: ${role}`) 
        }catch(e){
            alert(e)
        }
    }

    const UserList=async(e)=>{
        e.preventDefault()
        try{
            let ul = await Contract.methods.get_users().call()
            let ullength = await Contract.methods.get_users_amount().call()
            alert(`Users: ${ul}; \nUsers amount = ${ullength}`)
        }catch(e){
            alert(e)
        }
    }

    const Admins=async(e)=>{
        e.preventDefault()
        try{
            let a = await Contract.methods.get_admins().call()
            let aa = await Contract.methods.get_admin_amounts().call()
            alert(
            "Admins:" + a + "\n" +  
            "Admins amount = " + aa + "\n")
        }catch(e){
            alert(e)
        }
    }
//--------------------------------------------------------REGISTRATION---------------------------------------------
    const Registration=async(e)=>{
        e.preventDefault()
        try{
            let adr = await web3.eth.personal.newAccount(password)
            let Users = await web3.eth.getAccounts()
            await web3.eth.sendTransaction({from:Users[0], to:adr, gas:200000, value: 50 * (10**18)})
            Users[0] = "Choose address"
            setAccounts(Users)
            await web3.eth.personal.unlockAccount(adr, password, 99999)
            await Contract.methods.create_user(Login, password).send({from:adr, gas:200000})
            alert("Registration successfull. Remember your address: " + adr)
        }catch(e){
            alert(e)
        }
    }
//--------------------------------------------------------AUTORISATION---------------------------------------
    const Autorisation=async(e)=>{
        e.preventDefault()
        try{
            await web3.eth.personal.unlockAccount(address, password, 99999)
            sessionStorage.setItem("address", address)
            e.target.reset()
            alert("Autorisation successfull")
        }catch(e){
            alert(e)
        }
    }
//---------------------------------------------------------TRANSFERS---------------------------------------------------------------------------------
    const CreateTransfer=async(e)=>{
        e.preventDefault()
        try{
            await Contract.methods.create_transfer(addressTo, category, description, codeword).send({from:address, value:value * (10**18)})
            const TransferID = await Contract.methods.get_transfer_id().call()
            e.target.reset()
            alert(`Transfer ID: ${TransferID}`)
        }catch(e){
            alert(e)
        }
    }

    const StopTransfer=async(e)=>{
        e.preventDefault()
        try{
            await Contract.methods.stop_my_transfer(TransferID).send({from:address})
            e.target.reset()
            alert("Transfer stopped")
        }catch(e){
            alert(e)
        }
    }

    const GetTransfer=async(e)=>{
        e.preventDefault(e)
        try{
            await Contract.methods.get_my_transfer(TransferID, codeword).send({from:address})
            e.target.reset()
            alert("Transfer recived")
        }catch(e){
            alert(e)
        }
    }

    const TransferInfo=async(e)=>{
        e.preventDefault()
        try{
            let id = await Contract.methods.get_transfer_id().call()
            for (let i=0; i<=id; i++) {
                const array = await Contract.methods.get_transfer_info(i).call()
                if(array[0] === address || array[1] === address) {
                    alert(
                        "From: " + array[0] + "\n" +
                        "To: " + array[1] + "\n" +
                        "Description: " + array[2] + "\n" +
                        "Codeword: " + array[3] + "\n" +
                        "Category: " + array[4] + "\n" + 
                        "Value: " + array[5] + "\n" +
                        "Finished: " + array[6] + "\n"
                    )
                }
            }
        }catch(e){
            alert("Not transfers")
        }
    }

    const createTemplate=async(e)=>{
        e.preventDefault();
        try{
            await Contract.methods.create_template(nameTemplate, category, valueTemplate).send({from:address});
            let tmp = await Contract.methods.get_templates_name().call();
            alert(`Все шаблоны в системе теперь выглядят так: \n ${tmp}`);
        }
        catch(e){
            alert(e);
        }
    }

    const useTemplate=async(e)=>{
        e.preventDefault();
            try{
                const tmp = await Contract.methods.get_money_template(nameTemplate).call();
                await Contract.methods.use_template(nameTemplate, address, description, codeword).send({from:address, value: tmp});
                const transferId = await Contract.methods.getRransferID().call();
                alert("Вы создали транзакцию по шаблону: " + transferId );
            }
            catch(e){
                alert(e);
            }
    }
//----------------------------------------------------------CATEGORIES---------------------------------------
    const CreateCategory=async(e)=>{
        e.preventDefault()
        try{
            await Contract.methods.create_category(name).send({from:address})
            e.target.reset()
            alert("New category create: " + name)
        }catch(e){
            alert(e)
        }
    }

    const GetCategories=async(e)=>{
        e.preventDefault()
        try{
            let cats = await Contract.methods.get_categories().call()
            let cats_amount = await Contract.methods.get_categories_amount().call()
            alert(`Categories: \n${cats}; \nCategories amount = ${cats_amount}`)
        }catch(e){
            alert(e)
        }
    }
//-------------------------------------------------------------VOTE------------------------------------------------
    const StartVote=async(e)=>{
        e.preventDefault()
        try{
            const addressToBoost = address
            await Contract.methods.offer_to_boost(addressToBoost).send({from:address})
            let tmp = await Contract.methods.get_offer_amount().call()
            e.target.reset()
            alert("Vote started \n Vote ID: " + tmp)
            setVote(true)
        }catch(e){
            alert(e)
        }
    }

    const VoteYes=async(e)=>{
        e.preventDefault()
        try{
            if (voteUser === false) {
                await Contract.methods.vote_for(offerID).send({from:address})
                e.target.reset()
                alert("You vote for")
                setVote(true)
            }
            else{
                alert("Error: you already voted")
            }
        }catch(e){
            alert(e)
        }
    }

    const VoteNo=async(e)=>{
        e.preventDefault()
        try{
            if(voteUser === false) {
                await Contract.methods.vote_against(offerID).send({from:address})
                e.target.reset()
                alert("You vote against")
                setVote(true)
                alert("Vote canceled")
            }
            else{
                alert("Error: you already voted")
            }
        }catch(e){
            alert(e)
        }
    }

    const GetVoteYes=async(e)=>{
        e.preventDefault()
        try{
            const tmp = await Contract.methods.get_yes(offerID).call()
            e.target.reset()
            alert("Those who vote for = " + tmp)
        }catch(e){
            alert(e)
        }
    }

    const GetInfoBoost=async(e)=>{
        e.preventDefault()
        try{
            const tmp = await Contract.methods.get_info_boost(offerID).call()
            e.target.reset()
            alert(
                "User to boost: " + tmp[1] + "\n" +
                "Those who voted for: " + tmp[2] + "\n" +
                "Those who voted against: " + tmp[3] + "\n" +
                "Finished: " + tmp[4] + "\n"
            )
        }catch(e){
            alert(e)
        }
    }
//-------------------------------------------------------------------------------------------------------------------------
    return(
        <>
            <div className="lite">
                <h3><center>InterFace</center></h3>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/> 
            </div>
            <h4>User Info</h4>
            <form onSubmit = {UserInfo}>
                <button>Get</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Users</h4>
            <form onSubmit={UserList}>
                <button>Get</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Admins</h4>
            <form onSubmit={Admins}>
                <button>Get</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Categories</h4>
            <form onSubmit={GetCategories}>
                <button>Get</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Registration</h4>
            <form onSubmit={Registration}>
                <input required placeholder = "Login" onChange ={(e)=>setLogin(e.target.value)}/><br/>
                <input required placeholder = "Password" type="password" onChange ={(e)=>setPassword(e.target.value)}/><br/>
                <button>Continue</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/> 
            </form>
            <h4>Autorisation</h4>
            <form onSubmit={Autorisation}>
            <select onChange = {(e)=>setAddress(e.target.value)}>
                {Accounts.map((arr,i)=><option key={i} value={String(arr)}>{arr}</option>)}
                </select>
                <input required placeholder = "Password" type="password" onChange ={(e)=>setPassword(e.target.value)}/><br/>
                <button>Continue</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Transfers Info</h4>
            <form onSubmit={TransferInfo}>
                <button>Get</button>
                <hr align="center" wigth="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Create Transfer</h4>
            <form onSubmit={CreateTransfer}>
                <input required placeholder = "Address to" onChange ={(e)=>setAddressTo(e.target.value)}/><br/>
                <input required placeholder = "Category" onChange = {(e)=>setCategory(e.target.value)}/><br/>
                <input required placeholder = "Description" onChange = {(e)=>setDescription(e.target.value)}/><br/>
                <input required placeholder = "Codeword" type="password" onChange = {(e)=>setCodeword(e.target.value)}/><br/>
                <input required placeholder = "Value" onChange = {(e)=>setValue(e.target.value)}/><br/>
                <input type="checkbox" checked={checked} onChange={chengeCheckbox} />
                <button>Create</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Stop Transfer</h4>
            <form onSubmit={StopTransfer}>
                <input required placeholder = "Transfer ID" onChange = {(e)=>setTransferID(e.target.value)}/><br/>
                <button>Stop</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Get Transfer</h4>
            <form onSubmit={GetTransfer}>
                <input required placeholder = "Transfer ID" onChange = {(e)=>setTransferID(e.target.value)}/><br/>
                <input required placeholder = "Codeword" type="password" onChange = {(e)=>setCodeword(e.target.value)}/><br/>
                <button>Get</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Create Template</h4>
            <form onSubmit={createTemplate}>
            <input required placeholder="name template" onChange={(e) => setNameTemplate(e.target.value)}/><br/>
                <input required placeholder="category" onChange={(e) => setCategory(e.target.value)}/><br/>
                <input required placeholder="value template" onChange={(e) => setValueTemplate(e.target.value)}/><br/>
                <button>Create</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Use Template</h4>
            <form onSubmit={useTemplate}>
            <input required placeholder="name template" onChange={(e) => setNameTemplate(e.target.value)}/><br/>
                <input required placeholder="address to" onChange={(e) => setAddress(e.target.value)}/><br/>
                <input required placeholder="description" onChange={(e) => setDescription(e.target.value)}/><br/>
                <input required placeholder="codeword" type="password" onChange={(e) => setCodeword(e.target.value)}/><br/>
                <button>Use</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Create Category</h4>
            <form onSubmit={CreateCategory}>
                <input required placeholder = "Name" onChange = {(e)=>setName(e.target.value)}/><br/>
                <button>Create</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Start Vote</h4>
            <form onSubmit={StartVote}>
                <input required placeholder = "User to boost" onChange = {(e)=>setAddress(e.target.value)}/><br/>
                <button>Start</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Vote For</h4>
            <form onSubmit={VoteYes}>
                <input required placeholder = "Offer ID" onChange = {(e)=>setOfferID(e.target.value)}/><br/>
                <button>Vote</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Vote Against</h4>
            <form onSubmit={VoteNo}>
                <input required placeholder = "Offer ID" onChange = {(e)=>setOfferID(e.target.value)}/><br/>
                <button>Vote</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Votes "For" Amount</h4>
            <form onSubmit={GetVoteYes}>
                <input required placeholder = "Offer ID" onChange = {(e)=>setOfferID(e.target.value)}/><br/>
                <button>Get</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
            <h4>Vote Info</h4>
            <form onSubmit={GetInfoBoost}>
                <input required placeholder = "Offer ID" onChange = {(e)=>setOfferID(e.target.value)}/><br/>
                <button>Get</button>
                <hr align="center" width="100%" size="5" color="0000aaxf"/>
            </form>
        </>
    )
}
export default Main