import React from "react"
import {Switch, Route} from "react-router-dom"
import Main from "./Main"

const Routers =()=> {
    return(
    <>
    <Switch>
        <Route path ="/Main" component={Main} exact/>
        <Route path ="/" component={Main} exact/>
    </Switch>
    </>
    )
}
export default Routers